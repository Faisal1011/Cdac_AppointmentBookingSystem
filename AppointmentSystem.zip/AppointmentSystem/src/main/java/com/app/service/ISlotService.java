package com.app.service;

import java.time.LocalDate;
import java.util.List;

import com.app.pojos.Slot;
import com.app.pojos.Status;

public interface ISlotService {

	
}
