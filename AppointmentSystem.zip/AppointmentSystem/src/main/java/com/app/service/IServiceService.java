package com.app.service;

import java.util.List;

import com.app.pojos.Service;

public interface IServiceService {

	List<Service> getAllServices();
    
}
