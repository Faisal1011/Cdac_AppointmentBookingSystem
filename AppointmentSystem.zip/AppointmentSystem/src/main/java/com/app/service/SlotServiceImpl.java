package com.app.service;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.pojos.Slot;
import com.app.pojos.Status;

@Service
@Transactional
public class SlotServiceImpl implements ISlotService {
	

}
