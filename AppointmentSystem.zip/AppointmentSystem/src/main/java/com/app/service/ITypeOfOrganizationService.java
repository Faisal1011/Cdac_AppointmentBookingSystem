package com.app.service;
import java.util.List;

import com.app.pojos.TypeOfOrganization;
public interface ITypeOfOrganizationService {
 
	List<TypeOfOrganization> getAllTypeOfOrganizations();
	
}
