package com.app.pojos;

public enum Gender {
   MALE,FEMALE
}
