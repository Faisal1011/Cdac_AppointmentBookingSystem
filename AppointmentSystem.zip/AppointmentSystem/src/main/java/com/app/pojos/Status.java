package com.app.pojos;

public enum Status {
	AVAILABLE,NOT_AVAILABLE
}
