import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-as-admin',
  templateUrl: './login-as-admin.component.html',
  styleUrls: ['./login-as-admin.component.css']
})
export class LoginAsAdminComponent implements OnInit {

  constructor(private router:Router) { }

  loginAdmin()
  {
     
  }
  ngOnInit(): void {
  }

}
