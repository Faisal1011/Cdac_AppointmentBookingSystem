import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginAsOrganizationComponent } from './login-as-organization.component';

describe('LoginAsOrganizationComponent', () => {
  let component: LoginAsOrganizationComponent;
  let fixture: ComponentFixture<LoginAsOrganizationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginAsOrganizationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginAsOrganizationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
