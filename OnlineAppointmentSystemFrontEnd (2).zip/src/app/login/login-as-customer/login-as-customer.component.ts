import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Customer } from 'src/app/models/customer.model';

import {LoginService} from '../login.service';



@Component({
  selector: 'app-login-as-customer',
  templateUrl: './login-as-customer.component.html',
  styleUrls: ['./login-as-customer.component.css']
})
export class LoginAsCustomerComponent implements OnInit {

  
constructor(private router:Router,private loginservice:LoginService) { };
customer:Customer=new Customer;

  msg!:string;
 ngOnInit(): void {
  }

  onSubmit()
  {
    
    this.loginservice.LoginAsCustomer(this.customer).subscribe(response=>{
    
      console.log(response)
      localStorage.setItem("customerid",response.cstId);
      this.router.navigate(['/customer/customer-dashboard']);
     
    },error=>{
        this.msg="Invalid Credential Details,Please Register First!!!!!";
    })
  }
 
  
  
 
}
