import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Organization } from 'src/app/models/organization.model';
import { TypeOfOrganization } from 'src/app/models/typeOfOrganization.model';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-register-as-organization',
  templateUrl: './register-as-organization.component.html',
  styleUrls: ['./register-as-organization.component.css']
})
export class RegisterAsOrganizationComponent implements OnInit {

  constructor(private router:Router,private registerService:RegisterService) { }

  organization:Organization=new Organization;
  orgType:TypeOfOrganization=new TypeOfOrganization;
  public TypeOfOrgs!:TypeOfOrganization[];
  conpassword="";
  msg="";
  selectedFile:any = null;
  selectedtype!:number;

  ngOnInit(): void {
    this.getTypeOfOrgs();
    
   
  }

  private getTypeOfOrgs(){
    this.registerService.getTypeOfOrgList().subscribe(response => {
      console.log(response);
      this.TypeOfOrgs=response;
    })
  }

  onOptionsSelected() {
    this.registerService.getTypeOfOrganizationById(this.selectedtype).subscribe(resp => 
      {
         this.orgType = resp;    
      },
      error =>{
        this.msg=error.message
      })
  }



public onFileChanged(event:any) {
  console.log(event);
  this.selectedFile = event.target.files[0];
}

onSubmit()
{
  this.registerService.RegisterOrganization(this.selectedFile,this.organization,this.orgType).subscribe(
    resp => {
      console.log(resp);
      this.router.navigate(['/login/organization']);
    },error=>{
      this.msg="Organization Already Register with this EmailId";
    }
  );
}


}