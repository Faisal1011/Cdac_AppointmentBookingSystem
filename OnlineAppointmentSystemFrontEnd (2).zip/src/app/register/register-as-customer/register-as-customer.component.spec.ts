import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterAsCustomerComponent } from './register-as-customer.component';

describe('RegisterAsCustomerComponent', () => {
  let component: RegisterAsCustomerComponent;
  let fixture: ComponentFixture<RegisterAsCustomerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterAsCustomerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterAsCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
