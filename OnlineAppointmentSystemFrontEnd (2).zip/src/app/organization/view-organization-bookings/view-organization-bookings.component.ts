import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrganizationService } from '../organization.service';

@Component({
  selector: 'app-view-organization-bookings',
  templateUrl: './view-organization-bookings.component.html',
  styleUrls: ['./view-organization-bookings.component.css']
})
export class ViewOrganizationBookingsComponent implements OnInit {

  public appointments:any;
  constructor(private router:Router,private organizationservice: OrganizationService) { }

  ngOnInit(): void {
    this.getAppointments();
  }
  logout(){
    localStorage.removeItem('organizationid');
    this.router.navigate(['/login/organization']);
  }

  
  filterArray(array: any[], filters: { [x: string]: (arg0: any) => unknown; }) {
    const filterKeys = Object.keys(filters);
    return array.filter((item: { [x: string]: any; }) => {
      // validates all filter criteria
      return filterKeys.every(key => {
        // ignores non-function predicates
        if (typeof filters[key] !== 'function') return true;
        return filters[key](item[key]);
      });
    });
  }
  getAppointments(){
    
    this.organizationservice.getAppointment().subscribe(
      (responses :any) => {
        var orgId = parseInt(localStorage.getItem("organizationid")!);         
        const filters = {
          appointmentOfOrg: (appointmentOfOrg: { orgId: any; }) => appointmentOfOrg.orgId == orgId
        };
        var filtered = this.filterArray(responses, filters);
        this.appointments = filtered;
        
      },
      error => {
        console.log(error);
      }
    );
  }


}
