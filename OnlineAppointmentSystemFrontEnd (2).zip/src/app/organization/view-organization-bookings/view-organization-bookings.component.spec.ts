import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewOrganizationBookingsComponent } from './view-organization-bookings.component';

describe('ViewOrganizationBookingsComponent', () => {
  let component: ViewOrganizationBookingsComponent;
  let fixture: ComponentFixture<ViewOrganizationBookingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewOrganizationBookingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewOrganizationBookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
