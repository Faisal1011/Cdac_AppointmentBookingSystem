import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { OrganizationService } from '../organization.service';

@Component({
  selector: 'app-view-organization-employees',
  templateUrl: './view-organization-employees.component.html',
  styleUrls: ['./view-organization-employees.component.css']
})
export class ViewOrganizationEmployeesComponent implements OnInit {

  public employee :any;
  constructor(private router:Router,private orgservice: OrganizationService,private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getEmployees();
  }
  logout(){
    localStorage.removeItem('organizationid');
    this.router.navigate(['/login/organization']);
  }


  filterArray(array: any[], filters: { [x: string]: (arg0: any) => unknown; }) {
    const filterKeys = Object.keys(filters);
    return array.filter((item: { [x: string]: any; }) => {
      // validates all filter criteria
      return filterKeys.every(key => {
        // ignores non-function predicates
        if (typeof filters[key] !== 'function') return true;
        return filters[key](item[key]);
      });
    });
  }

  getEmployees() {
    this.orgservice.getEmployee().subscribe(
      employeeResponse => {
        var orgId = parseInt(localStorage.getItem("organizationid")!);         
        const filters = {
          workForOrganization: (workForOrganization: { orgId: any; }) => workForOrganization.orgId == orgId
        };
        var filtered = this.filterArray(employeeResponse, filters);
        this.employee = filtered;
      },
      error => {
        console.log(error);
      }
    );
  }

  deleteEmployee(id:any){
    if(confirm("Are you sure you want to delete!")){
      this.toastr.success('Successfull!', 'Employee Deleted Successfully!');
      this.orgservice.deleteEmployee(id).subscribe(
        employeeResponse => {
         console.log(employeeResponse);
         this.employee = this.employee.filter((item: { empId: any; }) => item.empId != id);
        
        },
        error => {
          console.log(error);
        }
      );
    }
    else{
      return;
    }
    
  }

}
