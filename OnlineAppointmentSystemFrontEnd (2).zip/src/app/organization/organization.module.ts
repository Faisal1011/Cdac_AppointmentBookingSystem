import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrganizationDashboardComponent } from './organization-dashboard/organization-dashboard.component';
import { OrganizationService } from './organization.service';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { UpdateOrganizationProfileComponent } from './update-organization-profile/update-organization-profile.component';
import { ViewOrganizationBookingsComponent } from './view-organization-bookings/view-organization-bookings.component';
import { ViewOrganizationEmployeesComponent } from './view-organization-employees/view-organization-employees.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { AddServiceComponent } from './add-service/add-service.component';




@NgModule({
  declarations: [OrganizationDashboardComponent,  UpdateOrganizationProfileComponent, ViewOrganizationBookingsComponent, ViewOrganizationEmployeesComponent, AddEmployeeComponent, AddServiceComponent],
  imports: [
    CommonModule,RouterModule,FormsModule,HttpClientModule
  ],
  exports:[OrganizationDashboardComponent],
  providers:[OrganizationService]
})
export class OrganizationModule { }
