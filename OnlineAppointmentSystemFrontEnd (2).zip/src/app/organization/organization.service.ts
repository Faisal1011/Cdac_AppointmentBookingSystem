import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../models/employee.model';

import { Organization } from '../models/organization.model';
import { TypeOfOrganization } from '../models/typeOfOrganization.model';

@Injectable({
  providedIn: 'root'
})
export class OrganizationService {

  url ='http://localhost:8080/'
  
  constructor(private httpClient: HttpClient) { }

  getOrganizationById(id:any)
  {
    return this.httpClient.get<any>(this.url +"/organizations" + `/${id}`);
  }
  getServiceById(id:any)
  {
    return this.httpClient.get<any>(this.url +"/services" + `/${id}`);
  }

  getTypeOfOrgList(){
    return this.httpClient.get<any[]>(this.url+"/typeOfOrgs");
  }

  getTypeOfOrganizationById(id:number)
  {
    return this.httpClient.get<any>(this.url +"/typeOfOrgs" + `/${id}`);
  }
  public UpdateOrganization(organization:Organization):Observable<any>
  {
   return this.httpClient.post(this.url+"/organizations/update",organization);
 
  }

  getAppointment(){
    return this.httpClient.get(this.url+"/appointments");
  }

  getEmployee(){
    return this.httpClient.get<any>(this.url+"employees");
  }

  getServices(){
    return this.httpClient.get<any>(this.url+"services");
  }
  deleteEmployee(id:any){
    
    return this.httpClient.delete(this.url+"employees/"+id);
  }
  public addEmployee(data:any):Observable<any>
  {
    return this.httpClient.post(this.url+"/employees/add",data);
  }
  public addService(data:any):Observable<any>
  {
    return this.httpClient.post(this.url+"/services/add",data);
  }

}
