import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateOrganizationProfileComponent } from './update-organization-profile.component';

describe('UpdateOrganizationProfileComponent', () => {
  let component: UpdateOrganizationProfileComponent;
  let fixture: ComponentFixture<UpdateOrganizationProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateOrganizationProfileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateOrganizationProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
