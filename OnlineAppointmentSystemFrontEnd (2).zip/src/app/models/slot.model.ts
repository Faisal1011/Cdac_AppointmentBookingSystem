
export class Slot
{
    slotId!:number;
    slotName!:string;
    date!:any;
    startingTime!:number;
    endingTime!:number;
    slotStatus!:string;
    Employee!:{
        empId: number;
        email: string;
        password: string;
        firstName: string;
        lastName: string;
        gender: string;
        mobileNo: string;
    }
    constructor(){
        
    }
    
}