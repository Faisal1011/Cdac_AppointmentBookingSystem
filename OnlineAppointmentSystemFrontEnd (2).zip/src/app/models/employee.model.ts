
export class Employee {
    empId!: number;
    email!: string;
    password!: string;
    firstName!: string;
    lastName!: string;
    gender!: string;
    mobileNo!: string;
    workForOrganization!: {
        orgId: number;
        email: string;
        password: string;
        nameOfOrganization: string;
        mobileNo: string;
        city: string;
        org_img: any;
        imageContentType: string;
        durationPerService: number;
    }
    serviceProvided!: {
        serId: number;
        serviceName: string;
        price: number;
    }
    constructor() {

    }

}