import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/models/customer.model';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-view-customer-profile',
  templateUrl: './view-customer-profile.component.html',
  styleUrls: ['./view-customer-profile.component.css']
})
export class ViewCustomerProfileComponent implements OnInit {

  customer:Customer=new Customer;
  custid = parseInt(localStorage.getItem("customerid")!);
  constructor(private router:Router,private customerService:CustomerService) { }

  ngOnInit(): void {
    this.customerService.getCustomerById(this.custid).subscribe(data => {
      console.log(data);
      this.customer=data;  
      })
  }
  logout(){
    localStorage.removeItem('customerid');
    localStorage.removeItem('orgTypeSelected');
    this.router.navigate(['/login/customer']);
  }
  onSubmit()
  {

  }

}
