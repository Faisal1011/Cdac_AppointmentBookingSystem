import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListOfOrgsComponent } from './list-of-orgs.component';

describe('ListOfOrgsComponent', () => {
  let component: ListOfOrgsComponent;
  let fixture: ComponentFixture<ListOfOrgsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListOfOrgsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListOfOrgsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
