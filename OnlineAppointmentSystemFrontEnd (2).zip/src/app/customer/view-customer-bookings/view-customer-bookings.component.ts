import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-view-customer-bookings',
  templateUrl: './view-customer-bookings.component.html',
  styleUrls: ['./view-customer-bookings.component.css']
})
export class ViewCustomerBookingsComponent implements OnInit {

  public appointments: any;
  constructor( private router:Router,private customerService: CustomerService,private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getAppointments();
  }
  logout(){
    localStorage.removeItem('customerid');
    localStorage.removeItem('orgTypeSelected');
    this.router.navigate(['/login/customer']);
  }

  
  filterArray(array: any[], filters: { [x: string]: (arg0: any) => unknown; }) {
    const filterKeys = Object.keys(filters);
    return array.filter((item: { [x: string]: any; }) => {
      // validates all filter criteria
      return filterKeys.every(key => {
        // ignores non-function predicates
        if (typeof filters[key] !== 'function') return true;
        return filters[key](item[key]);
      });
    });
  }

  getAppointments(){
    this.customerService.getAppointment().subscribe(
      (responses :any) => {
        debugger;
        console.log(responses);
         var cust = parseInt(localStorage.getItem("customerid")!);
        const filters = {
          appointmentOfCust: (appointmentOfCust: { cstId: any; }) => appointmentOfCust.cstId == cust
        };
        var filtered = this.filterArray(responses, filters);
        this.appointments = filtered;
      },
      error => {
        console.log(error);
      }
    );
  }


}
