import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Customer } from 'src/app/models/customer.model';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-update-customer-profile',
  templateUrl: './update-customer-profile.component.html',
  styleUrls: ['./update-customer-profile.component.css']
})
export class UpdateCustomerProfileComponent implements OnInit {

  conpassword:any;
  customer:Customer=new Customer;
  custid = parseInt(localStorage.getItem("customerid")!);
  public msg:any;
  constructor(private router:Router,private customerService:CustomerService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.customerService.getCustomerById(this.custid).subscribe(data => {
      console.log(data);
      this.customer=data;  
      })
  }

  logout(){
    localStorage.removeItem('customerid');
    localStorage.removeItem('orgTypeSelected');
    this.router.navigate(['/login/customer']);
  }
  onSubmit()
  {
    this.customerService.UpdateCustomer(this.customer).subscribe(response=>{
     
      this.toastr.success('Successfull!', 'Updated Successfully!');
    },error=>{
      this.toastr.warning('Error!', 'Something Went Wrong !');
    })
  }


}
