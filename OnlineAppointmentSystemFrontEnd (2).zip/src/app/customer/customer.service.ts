import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../models/customer.model';
import { TypeOfOrganization } from '../models/typeOfOrganization.model';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  url ='http://localhost:8080/'
  
  constructor(private httpClient: HttpClient) { }

  getTypeOfOrgList(): Observable<TypeOfOrganization[]>{
    return this.httpClient.get<TypeOfOrganization[]>(this.url+"/typeOfOrgs");
  }

  public UpdateCustomer(customer:Customer)
  {
    return this.httpClient.post(this.url+"/customers/update",customer);
  }

  getCustomerById(id:any)
  {
    return this.httpClient.get<any>(this.url +"/customers" + `/${id}`);
  }
  getOrganisations(){
    return this.httpClient.get<any>(this.url+"organizations");
  }

  getAllEmployees(){
    return this.httpClient.get<any>(this.url+"employees");
  }

  getAllServices(){
    return this.httpClient.get<any>(this.url+"services");
  }

  getSelectedService(id:any)
  {
    return this.httpClient.get<any>(this.url +"/services" + `/${id}`);
  }

  getSelectedSlot(id:any)
  {
    return this.httpClient.get<any>(this.url +"/slots" + `/${id}`);
  }
  updateSlots(data:any,id:any){
    return this.httpClient.put<any>(this.url+"slots/"+id, data);
  }

  bookAppointment(data: any){
    return this.httpClient.post<any>(this.url+"appointments",data);
  }

  getSlotsByDate(date :any){
    return this.httpClient.get(this.url+"slots/date/"+date);
  }

  getAppointment(){
    return this.httpClient.get(this.url+"appointments");
  }



}
