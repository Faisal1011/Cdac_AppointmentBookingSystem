import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeDashboardComponent } from './employee-dashboard/employee-dashboard.component';
import { EmployeeService } from './employee.service';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ViewEmployeeBookingsComponent } from './view-employee-bookings/view-employee-bookings.component';
import { UpdateEmployeeProfileComponent } from './update-employee-profile/update-employee-profile.component';



@NgModule({
  declarations: [EmployeeDashboardComponent, ViewEmployeeBookingsComponent, UpdateEmployeeProfileComponent],
  imports: [
    CommonModule,RouterModule,FormsModule,HttpClientModule
  ],
  exports:[EmployeeDashboardComponent],
  providers:[EmployeeService]
})
export class EmployeeModule { }
