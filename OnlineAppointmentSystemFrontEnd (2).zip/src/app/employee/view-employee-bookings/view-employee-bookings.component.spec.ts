import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewEmployeeBookingsComponent } from './view-employee-bookings.component';

describe('ViewEmployeeBookingsComponent', () => {
  let component: ViewEmployeeBookingsComponent;
  let fixture: ComponentFixture<ViewEmployeeBookingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewEmployeeBookingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewEmployeeBookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
