import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-view-employee-bookings',
  templateUrl: './view-employee-bookings.component.html',
  styleUrls: ['./view-employee-bookings.component.css']
})
export class ViewEmployeeBookingsComponent implements OnInit {

  public appointments: any;

  constructor(private router:Router,private employeeservice: EmployeeService) { }

  ngOnInit(): void {
    this.getAppointments();
  }
  logout(){
    localStorage.removeItem('employeeid');
    this.router.navigate(['/login/employee']);
  }

  filterArray(array: any[], filters: { [x: string]: (arg0: any) => unknown; }) {
    const filterKeys = Object.keys(filters);
    return array.filter((item: { [x: string]: any; }) => {
      // validates all filter criteria
      return filterKeys.every(key => {
        // ignores non-function predicates
        if (typeof filters[key] !== 'function') return true;
        return filters[key](item[key]);
      });
    });
  }


  getAppointments(){
    this.employeeservice.getAppointment().subscribe(
      (responses :any) => {
        console.log(responses);
         var empId = parseInt(localStorage.getItem("employeeid")!);         
        const filters = {
          appointmentOfEmp: (appointmentOfEmp: { empId: any; }) => appointmentOfEmp.empId == empId
        };
        var filtered = this.filterArray(responses, filters);
        this.appointments = filtered;
      },
      error => {
        console.log(error);
      }
    );
  }

}
