import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-update-employee-profile',
  templateUrl: './update-employee-profile.component.html',
  styleUrls: ['./update-employee-profile.component.css']
})
export class UpdateEmployeeProfileComponent implements OnInit {

  employee:any;
  empid = parseInt(localStorage.getItem("employeeid")!);
  conpassword:any;
  constructor(private router:Router,private employeeservice: EmployeeService,private toastr: ToastrService) { }

  ngOnInit(): void {
    this.employeeservice.getEmployee(this.empid).subscribe(data => {
      console.log(data);
      this.employee=data;  
      })
  }

  logout(){
    localStorage.removeItem('employeeid');
    this.router.navigate(['/login/employee']);
  }
  onSubmit()
  {
    this.employeeservice.UpdateEmployee(this.employee).subscribe(response=>{
     
      this.toastr.success('Successfull!', 'Updated Successfully!');
    },error=>{
      
    })
  }
}
