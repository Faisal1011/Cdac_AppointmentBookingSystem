import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Organization } from '../models/organization.model';
import { TypeOfOrganization } from '../models/typeOfOrganization.model';



@Injectable({
  providedIn: 'root'
})
export class StandardService {

  constructor(private Http:HttpClient) { }
  


  url = 'http://localhost:8080';

  getTypeOfOrgList(): Observable<TypeOfOrganization[]>{
    return this.Http.get<TypeOfOrganization[]>(this.url+"/typeOfOrgs");
  }
  
 
   

}
